package com.devkhishan.EmployeeManagementSystem.projections;

public interface EmployeeProjection {
    Long getId();
    String getName();
    String getEmail();
}
