package com.library.LibManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
